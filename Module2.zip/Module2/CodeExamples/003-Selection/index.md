# Lesson 
Go through Slides for Control Flow Selection

# Tutorial
Go through demo.py file

# Lab
Complete 'Selection Lab'