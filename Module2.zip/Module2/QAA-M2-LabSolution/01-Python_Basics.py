# Part 1 and 2 are guided, no exercise to do

# Part 3
length = int(input("Please enter length: "))
width = int(input("Please enter length: "))

perimeter = (length * 2) + (width * 2) 
area = length * width